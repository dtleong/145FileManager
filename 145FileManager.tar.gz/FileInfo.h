#include "FCB.h"
#include <time.h>
#include <stdio.h>

#define NAME_SIZE 6

void initFileInfo(); 
