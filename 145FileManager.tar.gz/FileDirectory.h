#include "FileInfo.h"
#include <stdio.h>

#define MAX_FILES 50

void initFileDirectory();

int fOpen(char* filename);
