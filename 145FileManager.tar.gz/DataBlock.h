#include <stdio.h>

#define MAX_BYTES 128

void initDataBlock();
