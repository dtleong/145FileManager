#include "DataBlock.h"
#include <stdio.h>

#define MAX_BLOCKS 4

void initFCB();
